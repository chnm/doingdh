# getty-institute-data
This repository provides working and sample datasets for Building a Digital Portfolio participants.

